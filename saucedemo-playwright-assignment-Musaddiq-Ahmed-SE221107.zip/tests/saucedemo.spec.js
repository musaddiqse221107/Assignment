const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { InventoryPage } = require('../pages/InventoryPage');
const { CartPage } = require('../pages/CartPage');
const { CheckoutPage } = require('../pages/CheckoutPage');

const validUser = {
  username: 'standard_user',
  password: 'secret_sauce'
};

async function loginAsStandardUser(page) {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(validUser.username, validUser.password);
  return new InventoryPage(page);
}

test.describe('Sauce Demo automation basics', () => {
  test('Login - valid credentials lands on inventory page', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const inventoryPage = new InventoryPage(page);

    await loginPage.goto();
    await loginPage.login(validUser.username, validUser.password);

    await expect(inventoryPage.inventoryContainer).toBeVisible();
    await expect(page).toHaveURL(/.*inventory\.html/);
  });

  test('Login - invalid password shows an error message', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.login(validUser.username, 'wrong_password');

    await expect(loginPage.errorMessage).toBeVisible();
    await expect(loginPage.errorMessage).toContainText(
      'Username and password do not match'
    );
  });

  test('Add 2 items to cart updates cart badge count', async ({ page }) => {
    const inventoryPage = await loginAsStandardUser(page);

    await inventoryPage.addItemToCart('Sauce Labs Backpack');
    await inventoryPage.addItemToCart('Sauce Labs Bike Light');

    await expect(inventoryPage.cartBadge).toHaveText('2');
  });

  test('Complete checkout shows thank you message', async ({ page }) => {
    const inventoryPage = await loginAsStandardUser(page);
    const cartPage = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);

    await inventoryPage.addItemToCart('Sauce Labs Backpack');
    await inventoryPage.openCart();
    await cartPage.checkout();
    await checkoutPage.enterCustomerInfo('John', 'Doe', '54000');
    await checkoutPage.finishOrder();

    await expect(checkoutPage.completeHeader).toBeVisible();
    await expect(checkoutPage.completeHeader).toHaveText(
      'Thank you for your order!'
    );
  });

  test('Logout redirects user back to login page', async ({ page }) => {
    const inventoryPage = await loginAsStandardUser(page);
    const loginPage = new LoginPage(page);

    await inventoryPage.logout();

    await expect(loginPage.loginButton).toBeVisible();
    await expect(page).toHaveURL('https://www.saucedemo.com/');
  });

  test('Sort products by price from low to high', async ({ page }) => {
    const inventoryPage = await loginAsStandardUser(page);

    await inventoryPage.sortByPriceLowToHigh();
    const prices = await inventoryPage.listedPrices();

    expect(prices[0]).toBeLessThan(prices[prices.length - 1]);
    expect(prices).toEqual([...prices].sort((a, b) => a - b));
  });
});
